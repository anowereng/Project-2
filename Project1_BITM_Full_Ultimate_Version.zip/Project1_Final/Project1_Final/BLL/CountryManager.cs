﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Project1_Final.DAL.Gateway;
using Project1_Final.DAL.Model;

namespace Project1_Final.BLL
{
    public class CountryManager
    {
        CountryGateway aCountryGateway = new CountryGateway();
        public string SaveCountry(Country aCountry)
        {
            if (aCountryGateway.IsCountryIsExist(aCountry.Name) != null)
            {
                return "<div class='alert alert-danger'><button aria-hidden='true' data-dismiss='alert' class='close' type='button'>×</button><h4><a class='alert-link'>Failed</a></h4> <strong>" + aCountry.Name + "</strong> is Already Exist !</div>";
            }
            else
            {
                int added = aCountryGateway.SaveContry(aCountry);
                if (added > 0)
                {
                    return "<div class='alert alert-info'><button aria-hidden='true' data-dismiss='alert' class='close' type='button'>×</button><h4><a class='alert-link'>Saved</a></h4> <strong>" + aCountry.Name + "</strong> is Successfully Saved !</div>";
                }
                else
                {
                    return "<div class='alert alert-danger'><button aria-hidden='true' data-dismiss='alert' class='close' type='button'>×</button><h4><a class='alert-link'>Failed</a></h4> <strong>" + aCountry.Name + "</strong> is Failed To Saved !</div>";
                }
            }
        }

        public List<Country> GetAllCountries()
        {
            return aCountryGateway.GetAllCountries();
        }
    }
}