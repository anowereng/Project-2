﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Project1_Final.DAL.ViewModel;
using Project1_Final.DAL.Gateway;

namespace Project1_Final.BLL
{
    public class CountriesViewManager
    {
        CountryViewModelGateway aCountriesViewModelGateway = new CountryViewModelGateway();
        public List<CountriesViewModel> SearchByCountry(string nameOfCountry)
        {
            return aCountriesViewModelGateway.SearchByCountryName(nameOfCountry);
        }

        public List<CountriesViewModel> GetAllCountriesView()
        {
            return aCountriesViewModelGateway.GetAllCountriesView();
        }
    }
}