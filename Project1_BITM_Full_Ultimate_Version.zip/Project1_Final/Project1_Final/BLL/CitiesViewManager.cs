﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Project1_Final.DAL.Gateway;
using Project1_Final.DAL.ViewModel;
using Project1_Final.DAL.Model;

namespace Project1_Final.BLL
{
    public class CitiesViewManager
    {
        CitiesViewModelGateway aCitiesViewModelGateway = new CitiesViewModelGateway();
        
        public List<CitiesViewModel> SearchByCityName(string nameOfCity)
        {
            return aCitiesViewModelGateway.SearchByCitiesName(nameOfCity);
        }

        public List<CitiesViewModel> SearchByCountryName(string nameOfCountry)
        {
            return aCitiesViewModelGateway.SearchByCountryName(nameOfCountry);
        }

        public List<Country> GetAllCountries()
        {
            return aCitiesViewModelGateway.GetAllCountry();
        }

        public List<CitiesViewModel> GetAllCities()
        {
            return aCitiesViewModelGateway.GetAllCities();
        }
    }
}