﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project1_Final.DAL.Model;
using Project1_Final.BLL;
using Project1_Final.DAL.ViewModel;

namespace Project1_Final.UI
{
    public partial class CityEntryUI : System.Web.UI.Page
    {
        CityManager aCityManager = new CityManager();
        CountryManager aCountryManager = new CountryManager();
        CityEntryViewManager aCityViewModelManager = new CityEntryViewManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetAllCountriesDropDownList();
            }
            PopulateCities();
        }

        protected void saveButton_Click(object sender, EventArgs e)
        {
            City aCity = new City();
            aCity.Name = nameTextbox.Text;
            aCity.About = aboutTextBox.Text;
            aCity.Dwellers = Convert.ToInt32(dwellersTextBox.Text);
            aCity.Location = locationTextBox.Text;
            aCity.Weather = weatherTextBox.Text;
            aCity.CountryId = Convert.ToInt32(countryDropDown.SelectedValue);
            messageLabel.Text = aCityManager.Save(aCity);
            PopulateCities();
            nameTextbox.Text = "";
            aboutTextBox.Text = "";
            dwellersTextBox.Text = "";
            locationTextBox.Text = "";
            weatherTextBox.Text = "";
            countryDropDown.ClearSelection();
        }

        public void GetAllCountriesDropDownList()
        {
            List<Country> allCountries = aCountryManager.GetAllCountries();
            countryDropDown.DataSource = allCountries;
            countryDropDown.DataTextField = "Name";
            countryDropDown.DataValueField = "Id";
            countryDropDown.DataBind();
        }

        public void PopulateCities()
        {
            cityGridView.DataSource = aCityViewModelManager.GetAllCities();
            cityGridView.DataBind();
        }
    }
}