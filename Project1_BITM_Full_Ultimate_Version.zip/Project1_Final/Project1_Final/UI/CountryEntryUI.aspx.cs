﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project1_Final.DAL.Model;
using Project1_Final.BLL;

namespace Project1_Final.UI
{
    public partial class CountryEntryUI : System.Web.UI.Page
    {
        CountryManager aCountryManager = new CountryManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            populaeCountries();
        }

        protected void saveButton_Click(object sender, EventArgs e)
        {
            Country aCountry = new Country();
            aCountry.Name = nameTextBox.Text;
            aCountry.About = aboutTextBox.Text;
            messageLabel.Text = aCountryManager.SaveCountry(aCountry);
            populaeCountries();
            nameTextBox.Text = "";
            aboutTextBox.Text = "";
        }

        public void populaeCountries()
        {
            List<Country> countries = aCountryManager.GetAllCountries();
            countryGridView.DataSource = countries;
            countryGridView.DataBind();
        }

        protected void resetButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("IndexUI.aspx");
        }
    }
}