﻿using Project1_Final.BLL;
using Project1_Final.DAL.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project1_Final
{
    public partial class ViewCountriesUI : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            PopulateCountries();
        }

        

        protected void OnPagination(Object sender, GridViewPageEventArgs e)
        {
            PopulateCountries();
            allCountriesViewGridView.PageIndex = e.NewPageIndex;
            allCountriesViewGridView.DataBind();
        }

        public void PopulateCountries()
        {
            CountriesViewManager aCountriesViewManager = new CountriesViewManager();
            allCountriesViewGridView.DataSource = aCountriesViewManager.GetAllCountriesView();
            allCountriesViewGridView.DataBind();
        }

        protected void searchButton_Click(object sender, EventArgs e)
        {
            CountriesViewManager aCountriesViewManager = new CountriesViewManager();
            CountriesViewModel aCountriesViewModel = new CountriesViewModel();
            aCountriesViewModel.CountryName = countryNameTextBox.Text;
            allCountriesViewGridView.DataSource = aCountriesViewManager.SearchByCountry(aCountriesViewModel.CountryName);
            allCountriesViewGridView.DataBind();
        }
    }
}