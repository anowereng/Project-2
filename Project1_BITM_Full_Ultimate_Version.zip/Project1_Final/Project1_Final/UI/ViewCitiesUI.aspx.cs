﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Project1_Final.DAL.Model;
using Project1_Final.DAL.ViewModel;
using Project1_Final.DAL.Gateway;
using Project1_Final.BLL;

namespace Project1_Final.UI
{
    public partial class ViewCitiesUI : System.Web.UI.Page
    {
        CountryManager aCountryManager = new CountryManager();
        CitiesViewManager aCitiesViewManager = new CitiesViewManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetAllCountriesDropDownList();
            }
            PopulateCities();
        }

        public void GetAllCountriesDropDownList()
        {
            List<Country> allCountries = aCountryManager.GetAllCountries();
            countryDropDown.DataSource = allCountries;
            countryDropDown.DataTextField = "Name";
            countryDropDown.DataValueField = "Id";
            countryDropDown.DataBind();
        }

        public void PopulateCities()
        {
            allCitesViewGridView.DataSource = aCitiesViewManager.GetAllCities();
            allCitesViewGridView.DataBind();
        }

        protected void searchButton_Click(object sender, EventArgs e)
        {
            //messageLabel.Text = "Alhamdulillah...";

            if (cityRadioButton.Checked)
            {
                string cityName = cityNameTextBox.Text;
                allCitesViewGridView.DataSource = aCitiesViewManager.SearchByCityName(cityName);
                allCitesViewGridView.DataBind();
                cityRadioButton.Checked = true;
                countryRadioButton.Checked = false;
                messageLabel.Text = "";
            }
            else if (countryRadioButton.Checked)
            {
                string countryName = countryDropDown.SelectedItem.ToString();
                allCitesViewGridView.DataSource = aCitiesViewManager.SearchByCountryName(countryName);
                allCitesViewGridView.DataBind();
                cityNameTextBox.Text = "";
                cityRadioButton.Checked = false;
                countryRadioButton.Checked = true;
                messageLabel.Text = "";
            }
            else
            {
                messageLabel.Visible = true;
                messageLabel.Text = "Select a Radio Button First !";
                cityNameTextBox.Text = "";
                cityRadioButton.Checked = false;
                countryRadioButton.Checked = false;
            }

        }
    }
}