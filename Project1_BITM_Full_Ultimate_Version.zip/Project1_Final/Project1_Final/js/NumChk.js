﻿function checkNum() {
    if ((event.keyCode > 64 && event.keyCode < 91) || (event.keyCode > 96 && event.keyCode < 123) || event.keyCode == 8)
        return true;
    else {
        alert("Sorry\nCountry Name Can't be Numeric Value");
        return false;
    }

}