﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Project1_Final.DAL.Model;

namespace Project1_Final.DAL.Gateway
{
    public class CityGateway : Gateway
    {
        public int SaveCity(City aCity)
        {
            //Query = "insert into City (Name,About,dweller,location,weather,countryId) values ('"+aCity.Name+"','"+aCity.About+"',"+aCity.Dwellers+",'"+aCity.Location+"','"+aCity.Weather+"',"+aCity.CountryId+")";
            Query = "insert into City (Name,About,dweller,location,weather,countryId) values (@Name,@About,@dweller,@location,@weather,@countryId)";
            Connection.Open();
            Command = new SqlCommand(Query,Connection);
            
            Command.Parameters.Clear();
            Command.Parameters.Add("Name",SqlDbType.VarChar);
            Command.Parameters["Name"].Value = aCity.Name;
            Command.Parameters.Add("About",SqlDbType.NVarChar);
            Command.Parameters["About"].Value = aCity.About;
            Command.Parameters.Add("dweller",SqlDbType.Int);
            Command.Parameters["dweller"].Value = aCity.Dwellers;
            Command.Parameters.Add("location",SqlDbType.VarChar);
            Command.Parameters["location"].Value = aCity.Location;
            Command.Parameters.Add("weather",SqlDbType.VarChar);
            Command.Parameters["weather"].Value = aCity.Weather;
            Command.Parameters.Add("countryId",SqlDbType.Int);
            Command.Parameters["countryId"].Value = aCity.CountryId;
            
            int rowAffect = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffect;
        }

        public City IsCityIsExist(string cityName, int countryId)
        {
            Query = @"select * from city where Name='" + cityName + "' and countryId=" + countryId;
            Connection.Open();
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            City aCity = null;
            if (Reader.HasRows)
            {
                Reader.Read();
                aCity = new City();
                aCity.Id = Convert.ToInt32(Reader["Id"]);
                aCity.Name = Reader["Name"].ToString();
                aCity.About = Reader["About"].ToString();
                aCity.Dwellers = Convert.ToInt32(Reader["dweller"]);
                aCity.Location = Reader["location"].ToString();
                aCity.Weather = Reader["weather"].ToString();
                aCity.CountryId = Convert.ToInt32(Reader["countryId"]);
            }
            Reader.Close();
            Connection.Close();
            return aCity;
        }

        public List<City> GetAllCities()
        {
            Query = @"select * from City";
            Connection.Open();
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<City> allCities = new List<City>();
            while (Reader.Read())
            {
                City aCity = new City();
                aCity.Id = Convert.ToInt32(Reader["Id"]);
                aCity.Name = Reader["Name"].ToString();
                aCity.About = Reader["About"].ToString();
                aCity.Dwellers = Convert.ToInt32(Reader["dweller"]);
                aCity.Location = Reader["location"].ToString();
                aCity.Weather = Reader["weather"].ToString();
                aCity.CountryId = Convert.ToInt32(Reader["countryId"]);
                allCities.Add(aCity);
            }
            Reader.Close();
            Connection.Close();
            return allCities;
        }

    }
}