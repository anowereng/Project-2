﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace Project1_Final.DAL.Gateway
{
    public class Gateway
    {
        public SqlConnection Connection { get; set; }
        public SqlCommand Command { get; set; }
        public SqlDataReader Reader { get; set; }
        public string Query { get; set; }
        private string ConnectionString = WebConfigurationManager.ConnectionStrings["CountryCityManagementDB"].ToString();

        public Gateway()
        {
            Connection = new SqlConnection(ConnectionString);
            Command = new SqlCommand();
        }
    }
}