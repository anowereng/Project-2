﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Project1_Final.DAL.ViewModel;

namespace Project1_Final.DAL.Gateway
{
    public class CountryViewModelGateway : Gateway
    {
        public List<CountriesViewModel> SearchByCountryName(string nameOfCountry)
        {
            Query = @"select * from CountriesView where CountryName like '%" + nameOfCountry + "%' order by CountryName";
            Connection.Open();
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<CountriesViewModel> allCountriesView = new List<CountriesViewModel>();
            while (Reader.Read())
            {
                CountriesViewModel aCountriesViewModel = new CountriesViewModel();
                aCountriesViewModel.CountryName = Reader["CountryName"].ToString();
                aCountriesViewModel.AboutCountry = Reader["AboutCountry"].ToString();
                aCountriesViewModel.TotalCity = Convert.ToInt32(Reader["TotalCity"]);
                aCountriesViewModel.TotalDweller = Convert.ToInt32(Reader["TotalDweller"]);
                allCountriesView.Add(aCountriesViewModel);
            }
            Reader.Close();
            Connection.Close();
            return allCountriesView;
        }

        public List<CountriesViewModel> GetAllCountriesView()
        {
            Query = "select * from CountriesView2 order by CountryName";
            Connection.Open();
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<CountriesViewModel> allCountriesView = new List<CountriesViewModel>();
            while (Reader.Read())
            {
                CountriesViewModel aCountriesViewModel = new CountriesViewModel();
                aCountriesViewModel.CountryName = Reader["CountryName"].ToString();
                aCountriesViewModel.AboutCountry = Reader["AboutCountry"].ToString();
                aCountriesViewModel.TotalCity = Convert.ToInt32(Reader["TotalCity"]);
                //aCountriesViewModel.TotalCity = 0;
                if (Reader["TotalDweller"] == DBNull.Value)
                {
                    aCountriesViewModel.TotalDweller = 0;
                }
                else
                {
                    aCountriesViewModel.TotalDweller = Convert.ToInt32(Reader["TotalDweller"]);
                }
                //aCountriesViewModel.TotalDweller = Convert.ToInt32(Reader["TotalDweller"]);
                allCountriesView.Add(aCountriesViewModel);
            }
            Reader.Close();
            Connection.Close();
            return allCountriesView;
        }
    }
}