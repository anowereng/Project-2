﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Project1_Final.DAL.ViewModel;
using Project1_Final.DAL.Model;

namespace Project1_Final.DAL.Gateway
{
    public class CitiesViewModelGateway : Gateway
    {

        public List<Country> GetAllCountry()
        {
            Query = "select Id,Name from country";
            Command = new SqlCommand(Query,Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            List<Country> allCountry = new List<Country>();
            while (Reader.Read())
            {
                Country aCountry = new Country();
                aCountry.Id = Convert.ToInt32(Reader["Id"]);
                aCountry.Name = Reader["Name"].ToString();
                allCountry.Add(aCountry);
            }
            Reader.Close();
            Connection.Close();
            return allCountry;
        }

        public List<CitiesViewModel> SearchByCitiesName(string nameOfCity)
        {
            Query = @"select * from CitiesView where CityName like '%"+nameOfCity+"%'";
            //Query = "select * from CitiesView where CityName like '%@Name%'";
            Connection.Open();
            Command = new SqlCommand(Query, Connection);
            /*
            Command.Parameters.Clear();
            Command.Parameters.Add("Name", SqlDbType.VarChar);
            Command.Parameters["Name"].Value = nameOfCity;
            */
            Reader = Command.ExecuteReader();
            List<CitiesViewModel> allCitiesView = new List<CitiesViewModel>();
            while (Reader.Read())
            {
                CitiesViewModel aCitiesView = new CitiesViewModel();
                aCitiesView.CityName = Reader["CityName"].ToString();
                aCitiesView.About = Reader["About"].ToString();
                aCitiesView.Location = Reader["Location"].ToString();
                aCitiesView.CountryName = Reader["CountryName"].ToString();
                aCitiesView.Weather = Reader["Weather"].ToString();
                aCitiesView.AboutCountry = Reader["AboutCountry"].ToString();
                aCitiesView.Dweller = Convert.ToInt32(Reader["Dweller"]);
                allCitiesView.Add(aCitiesView);
            }
            Reader.Close();
            Connection.Close();
            return allCitiesView;
        }

        public List<CitiesViewModel> SearchByCountryName(string nameOfCountry)
        {
            //Query = @"select * from CitiesView where CountryName='"+nameOfCountry+"'";
            Query = @"select * from CitiesView where CountryName=@CountryName";
            Connection.Open();
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("CountryName",SqlDbType.VarChar);
            Command.Parameters["CountryName"].Value = nameOfCountry;
            Reader = Command.ExecuteReader();
            List<CitiesViewModel> allCitiesView = new List<CitiesViewModel>();
            while (Reader.Read())
            {
                CitiesViewModel aCitiesView = new CitiesViewModel();
                aCitiesView.CityName = Reader["CityName"].ToString();
                aCitiesView.About = Reader["About"].ToString();
                aCitiesView.Location = Reader["Location"].ToString();
                aCitiesView.CountryName = Reader["CountryName"].ToString();
                aCitiesView.Weather = Reader["Weather"].ToString();
                aCitiesView.AboutCountry = Reader["AboutCountry"].ToString();
                aCitiesView.Dweller = Convert.ToInt32(Reader["Dweller"]);
                allCitiesView.Add(aCitiesView);
            }
            Reader.Close();
            Connection.Close();
            return allCitiesView;
        }

        public List<CitiesViewModel> GetAllCities()
        {
            Query = "select * from CitiesView";
            Connection.Open();
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<CitiesViewModel> allCitiesView = new List<CitiesViewModel>();
            while (Reader.Read())
            {
                CitiesViewModel aCitiesView = new CitiesViewModel();
                aCitiesView.CityName = Reader["CityName"].ToString();
                aCitiesView.About = Reader["About"].ToString();
                aCitiesView.Weather = Reader["Weather"].ToString();
                aCitiesView.Location = Reader["Location"].ToString();
                aCitiesView.CountryName = Reader["CountryName"].ToString();
                aCitiesView.AboutCountry = Reader["AboutCountry"].ToString();
                aCitiesView.Dweller = Convert.ToInt32(Reader["Dweller"]);
                allCitiesView.Add(aCitiesView);
            }
            Reader.Close();
            Connection.Close();
            return allCitiesView;
        }

        //public List<CitiesViewModel> OnIndexChanging()
        //{

        //}
    }
}