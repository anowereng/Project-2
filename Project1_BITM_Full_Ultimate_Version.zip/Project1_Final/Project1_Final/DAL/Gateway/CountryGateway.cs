﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Project1_Final.DAL.Model;

namespace Project1_Final.DAL.Gateway
{
    public class CountryGateway : Gateway
    {
        public int SaveContry(Country aCountry)
        {
            
            //Query = @"insert into Country (Name,About) values ('" + aCountry.Name + "','" + aCountry.About + "')";
            
            Query = "insert into Country (Name,About) values (@Name,@About)";
            Connection.Open();
            Command = new SqlCommand(Query,Connection);
            
            Command.Parameters.Clear();
            Command.Parameters.Add("Name",SqlDbType.VarChar);
            Command.Parameters["Name"].Value = aCountry.Name;
            Command.Parameters.Add("About",SqlDbType.NVarChar);
            Command.Parameters["About"].Value = aCountry.About;
            
            int rowAffect = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffect;
        }

        public Country IsCountryIsExist(string countryName)
        {
            //Query = "select * from Country where Name='"+countryName+"'";
            Query = "select * from Country where Name=@Name";
            Connection.Open();
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("Name",SqlDbType.VarChar);
            Command.Parameters["Name"].Value = countryName;
            Reader = Command.ExecuteReader();
            Country aCountry = null;
            if (Reader.HasRows)
            {
                Reader.Read();
                aCountry = new Country();
                aCountry.Id = Convert.ToInt32(Reader["Id"]);
                aCountry.Name = Reader["Name"].ToString();
                aCountry.About = Reader["About"].ToString();
            }
            Reader.Close();
            Connection.Close();
            return aCountry;
        }

        public List<Country> GetAllCountries()
        {
            Query = "select * from Country";
            Connection.Open();
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<Country> allCountries = new List<Country>();
            while (Reader.Read())
            {
                Country aCountry = new Country();
                aCountry.Id = Convert.ToInt32(Reader["Id"]);
                aCountry.Name = Reader["Name"].ToString();
                aCountry.About = Reader["About"].ToString();
                allCountries.Add(aCountry);
            }
            Reader.Close();
            Connection.Close();
            return allCountries;
        }
    }
}