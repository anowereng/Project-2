﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Project1_Final.DAL.ViewModel;

namespace Project1_Final.DAL.Gateway
{
    public class CityEntryViewModelGateway : Gateway
    {
        public List<CityEntryViewModel> GetAllCities()
        {
            Query = "select * from CityView";
            Command=new SqlCommand(Query,Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            CityEntryViewModel aCityViewModel = null;
            List<CityEntryViewModel> allCityEntryViewModel = new List<CityEntryViewModel>();
            while (Reader.Read())
            {
                aCityViewModel = new CityEntryViewModel();
                aCityViewModel.Name = Reader["Name"].ToString();
                aCityViewModel.CountryName = Reader["CountyName"].ToString();
                aCityViewModel.dweller = Convert.ToInt32(Reader["dweller"]);
                allCityEntryViewModel.Add(aCityViewModel);
            }
            Reader.Close();
            Connection.Close();
            return allCityEntryViewModel;
        }
    }
}