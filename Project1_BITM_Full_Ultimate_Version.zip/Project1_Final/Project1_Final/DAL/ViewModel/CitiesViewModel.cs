﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project1_Final.DAL.ViewModel
{
    public class CitiesViewModel
    {
        public string CityName { get; set; }
        public string About { get; set; }
        public int Dweller { get; set; }
        public string Location { get; set; }
        public string CountryName { get; set; }
        public string AboutCountry { get; set; }
        public string Weather { get; set; }
    }
}