﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Project1_Final.DAL.ViewModel
{
    public class CityEntryViewModel
    {
        public string Name { get; set; }
        public string CountryName { get; set; }
        public int dweller { get; set; }
    }
}